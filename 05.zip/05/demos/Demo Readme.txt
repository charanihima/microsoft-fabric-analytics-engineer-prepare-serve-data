===============================================================================
Microsoft Fabric Analytics Engineer: Prepare and Serve Data
	- Mohit Batra (linkedin.com/in/mohitbatra/)
===============================================================================

Demo files for all the modules are available in the root folder (or module 1 folder), in a file named "demos.zip".


Please go through Setup Instructions document to get started!

===========================
Happy Learning! :)
===========================